# GitHub Repository to Extractable Component Manifest

## Conversion

**Input:** A local Git repository snapshot supplied as a folder, file tree, and file contents. A GitHub URL may identify the repository, but it is not evidence of contents unless the corresponding snapshot is supplied.

**Output:** A Markdown Component Manifest with a fixed section order and fixed fields for every extracted component.

## Purpose

Convert repository evidence into a component-level handoff that another engineer or AI agent can extract, inspect, or replace without guessing. The manifest indexes source files, exported symbols, dependencies, routes, and configuration exactly as supplied.

## Contract

- Every output claim carries one or more source locators in the form `[path:line-start-line-end]`.
- The translator copies identifiers, literals, paths, and dependency names exactly as they appear in source.
- Fields with no supporting evidence contain `not in source`.
- The output is an inventory and mapping, not an architectural review, summary, recommendation, or refactor plan.
