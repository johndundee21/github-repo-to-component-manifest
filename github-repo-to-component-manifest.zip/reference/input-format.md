# Input Format

Supply a repository snapshot in plain text or Markdown using this structure:

```text
REPOSITORY IDENTIFIER (optional)
owner/repository

SOURCE SNAPSHOT IDENTIFIER (optional)
commit-or-export-label

FILE TREE
package.json
src/index.js
src/server.js

--- package.json ---
1: {"name":"example","dependencies":{"express":"^4.18.0"}}

--- src/index.js ---
1: export { start } from "./server.js";

--- src/server.js ---
1: import express from "express";
2: const app = express();
3: app.get("/health", (req, res) => res.send("ok"));
4: export function start() { app.listen(3000); }
```

## Constraints

- Paths in the file tree must match the paths used in file headers.
- Preserve original content; add line numbers only if they are absent.
- Do not omit files merely because they appear unimportant; omissions prevent complete coverage claims.
- For binary, generated, or unreadable files, provide the path and explicitly mark content unavailable. The translator will report this in Source Coverage and Translation Exceptions.
