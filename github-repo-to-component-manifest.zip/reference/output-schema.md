# Component Manifest Output Schema

The translator must return one Markdown document beginning with `# Component Manifest` and use every heading below in the stated order.

```markdown
# Component Manifest

## Repository Record
- Repository identifier: {directly supplied identifier or `not in source`}
- Source snapshot identifier: {directly supplied identifier or `not in source`}

## Source Coverage
| Path | Supplied content | Output mapping |
|---|---|---|
| `{path}` | `yes` or `no` | `{section references with source locators}` |

## Component Manifest
| Component ID | Kind | Name | Path | Definition | Explicit role | Evidence |
|---|---|---|---|---|---|---|
| `component-001` | `{file|class|function|export|constant|other explicit kind}` | `{exact name}` | `{exact path}` | `{visible defining text, compactly copied}` | `{explicit role or not in source}` | `[{path}:{start}-{end}]` |

## Dependency Manifest
| Dependency | Declared version or specifier | Declaration kind | Path | Evidence |
|---|---|---|---|---|
| `{exact dependency name}` | `{exact value or not in source}` | `{package dependency|import|require|other explicit kind}` | `{exact path}` | `[{path}:{start}-{end}]` |

## Route Manifest
| Route | Declaration kind | Path | Evidence |
|---|---|---|---|
| `{exact route text}` | `{exact declaration kind}` | `{exact path}` | `[{path}:{start}-{end}]` |

## Configuration Manifest
| Key | Value | Path | Evidence |
|---|---|---|---|
| `{exact key}` | `{exact visible value}` | `{exact path}` | `[{path}:{start}-{end}]` |

## Unmapped Source Items
| Path | Visible source item | Evidence |
|---|---|---|
| `{path}` | `{copied text or a concise non-interpretive file marker}` | `[{path}:{start}-{end}]` |

## Translation Exceptions
{`none found in source` or one bullet per incomplete, unreadable, ambiguous, or conflicting supplied item, with a source locator}
```

## Field definitions

| Field | Required | Meaning | Permitted content |
|---|---:|---|---|
| Component ID | Yes | Sequential manifest identifier | `component-001`, then increment by one |
| Kind | Yes | Explicitly evidenced entity type | Only a visibly supported type; otherwise omit the entity |
| Definition | Yes | Source-visible defining text | Compact copy of the definition; no paraphrase that adds meaning |
| Explicit role | Yes | Role text stated by the source | Exact stated role or `not in source` |
| Evidence | Yes | Trace locator | One or more `[path:start-end]` locators |
| Output mapping | Yes | Where supplied evidence appears | Section names and locators only |

## Locator format

Use `[relative/path.ext:line-start-line-end]`. If a claim depends on separate noncontiguous spans, use separate locators: `[src/a.js:1-1] [src/a.js:5-8]`.
