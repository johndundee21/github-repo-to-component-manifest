# Translation Rules

## Required evidence

Accept one repository snapshot per run:

1. A file tree with paths.
2. Text contents for files to be analyzed.
3. Line numbers, or text that can be numbered without changing its content.
4. Optional repository metadata only when it is included in the snapshot.

Do not fetch, infer, or use information from a GitHub URL, package registry, documentation site, commit history, or general knowledge unless that information is included in the supplied snapshot.

## Output order

Always emit sections in this exact order:

1. Repository Record
2. Source Coverage
3. Component Manifest
4. Dependency Manifest
5. Route Manifest
6. Configuration Manifest
7. Unmapped Source Items
8. Translation Exceptions

Emit every section even if every field is `not in source` or `none found in source`.

## Claim rules

- A component is an explicitly evidenced file, class, function, exported constant, route declaration, configuration key, or declared dependency.
- Preserve spelling, casing, punctuation, values, and paths exactly as written.
- Associate a symbol only with its containing file and the line range that visibly defines it.
- List a dependency only when it appears in a supplied manifest, import statement, require statement, or equivalent declared source line.
- List a route only when a supplied file visibly declares a route, endpoint, page path, or router mapping.
- List a configuration item only when a supplied configuration file or source line visibly declares it.
- Do not label a file as frontend, backend, entry point, unused, core, legacy, secure, broken, or production-ready unless those exact claims are stated in the source. Use `not in source` for the role field if no role is explicitly stated.
- Do not expand abbreviations, normalize names, calculate versions, infer frameworks, infer owners, or create descriptions.
- Do not treat comments, filenames, or directory names as evidence of runtime behavior.

## Missing and ambiguous evidence

- Use `not in source` for a required scalar field with no direct evidence.
- Use `none found in source` for an empty collection after examining supplied relevant files.
- If a line is unreadable, incomplete, or conflicting, copy the visible text only and record the issue in Translation Exceptions.
- If a supplied file has no lines, report it in Source Coverage and do not invent a component.

## Coverage rules

- Include every supplied file in Source Coverage.
- A file belongs in Unmapped Source Items when no claim from that file appears elsewhere in the output.
- Do not claim complete repository coverage if the input does not include a file tree and file contents.
