# GitHub Repo to Extractable Component Manifest

A folder-based AI translator that converts a supplied GitHub repository snapshot into a traceable inventory of components ready for extraction, inspection, or handoff.

## What it does

**Input:** A repository file tree and the contents of its files, preferably line-numbered.

**Output:** A fixed-shape Markdown Component Manifest that lists directly evidenced components, dependencies, routes, configuration items, unmapped source items, and translation exceptions.

Every output claim must point to a source locator. The translator never fetches a repository, guesses a framework, assigns an architectural role, or fills missing details.

## Folder contents

```text
github-repo-to-component-manifest/
├── identity.md
├── rules.md
├── examples.md
├── README.md
└── reference/
    ├── input-format.md
    └── output-schema.md
```

## Use in Claude

1. Create a Claude Project.
2. Upload this complete folder as Project Knowledge.
3. Paste one repository snapshot using `reference/input-format.md`.
4. Ask: `Translate this repository snapshot into the Component Manifest contract. Apply the folder rules exactly.`
5. Save the returned Markdown as `component-manifest.md` beside the snapshot.

## Required input

At minimum, provide:

- A file tree
- Contents for each file you want included
- Stable line numbers, either supplied or added without changing content

A GitHub URL is optional identification metadata. It is not permission to retrieve, assume, or invent repository content.

## Verification checklist

Before accepting an output, verify:

- Every required heading appears in the schema order.
- Every table row has at least one valid source locator.
- Every identifier, path, version, literal, and route matches the input exactly.
- Missing values say `not in source`.
- Empty result collections say `none found in source`.
- Every supplied file appears in Source Coverage.
- Files with no mapped claims appear in Unmapped Source Items.

## Example

See `examples.md` for two complete contract examples: a small JavaScript repository with an exported function and dependency, and a sparse repository with no extractable code components.

## Non-goals

This translator does not summarize the repository, evaluate code quality, propose refactors, estimate effort, infer service boundaries, generate documentation, or extract content from an unprovided GitHub URL.
