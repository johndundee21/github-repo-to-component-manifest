# Examples

## Example 1: Repository with a component and dependency

### Input snapshot

```text
FILE TREE
package.json
src/math.js

--- package.json ---
1: {"dependencies":{"lodash":"^4.17.21"}}

--- src/math.js ---
1: import _ from "lodash";
2: export function add(a, b) {
3:   return a + b;
4: }
```

### Output

```markdown
# Component Manifest

## Repository Record
- Repository identifier: not in source
- Source snapshot identifier: not in source

## Source Coverage
| Path | Supplied content | Output mapping |
|---|---|---|
| `package.json` | yes | Dependency Manifest `[package.json:1-1]` |
| `src/math.js` | yes | Component Manifest `[src/math.js:2-4]`; Dependency Manifest `[src/math.js:1-1]` |

## Component Manifest
| Component ID | Kind | Name | Path | Definition | Explicit role | Evidence |
|---|---|---|---|---|---|---|
| `component-001` | function | `add` | `src/math.js` | `export function add(a, b) { return a + b; }` | not in source | `[src/math.js:2-4]` |

## Dependency Manifest
| Dependency | Declared version or specifier | Declaration kind | Path | Evidence |
|---|---|---|---|---|
| `lodash` | `^4.17.21` | package dependency | `package.json` | `[package.json:1-1]` |
| `lodash` | `"lodash"` | import | `src/math.js` | `[src/math.js:1-1]` |

## Route Manifest
none found in source

## Configuration Manifest
none found in source

## Unmapped Source Items
none found in source

## Translation Exceptions
none found in source
```

## Example 2: Sparse repository

### Input snapshot

```text
FILE TREE
README.md

--- README.md ---
1: # Sample
```

### Output

```markdown
# Component Manifest

## Repository Record
- Repository identifier: not in source
- Source snapshot identifier: not in source

## Source Coverage
| Path | Supplied content | Output mapping |
|---|---|---|
| `README.md` | yes | Unmapped Source Items `[README.md:1-1]` |

## Component Manifest
none found in source

## Dependency Manifest
none found in source

## Route Manifest
none found in source

## Configuration Manifest
none found in source

## Unmapped Source Items
| Path | Visible source item | Evidence |
|---|---|---|
| `README.md` | `# Sample` | `[README.md:1-1]` |

## Translation Exceptions
none found in source
```
